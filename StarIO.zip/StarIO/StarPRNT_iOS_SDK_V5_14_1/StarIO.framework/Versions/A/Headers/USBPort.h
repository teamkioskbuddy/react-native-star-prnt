//
//  USBPort.h
//  StarIOPort
//
//  Created by u3237 on 2017/03/08.
//
//

#import "ExternalAccessoryPort.h"
#import "Util.h"

@interface USBPort : ExternalAccessoryPort

@end
